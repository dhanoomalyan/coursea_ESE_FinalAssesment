Author: Dhanoomalyan
Date: 04/23/2020

(See the Final Assessment pics uploaded with this project to know how to execute the makefile)

Coursera: Embedded Software Essentials
		
		by

	University of Colorado Boulder

Project Description

1) Incorporate a c-program application into your Make and GCC build system
2) Write c-program functions that manipulate memory
3) Execute and test your application by simulating it on the host machine


https://www.coursera.org/learn/introduction-embedded-systems/peer/prT70/expanded-build-system-and-memory
